<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class c extends CI_Controller {
	
	public function __construct()
	{
		parent::__construct();
		$this->load->database();
	}

	public function home()
	{
		$this->load->view('home');
	}
	
	public function insert()
	{
		$this->load->view('insert');
	}
	
	function index()
	{
		// $this->load->database();
		$data['vocer'] = $this->db->get('vocer')->result_array();
		$this->load->view('home', $data);
	}

	function insert_data()
	{
		$this->load->view('insert');
		$data = array(
			'nama_operator'=>$this->input->post('nama_operator'),
			'jumlah_pulsa'=>$this->input->post('jumlah_pulsa')
		);
		if ($data) {
			redirect('home');
		}
	}

}
