<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css">   
    <title>Document</title>
</head>
<body>
  <div class="card d-flex align-item-center">
    <div>
                <form action="c" method="post">
                  <div class="form-row">
                    <div class="form-group col-md-6">
                      <label>Nama Operator</label>
                      <input name="nama_operator" type="text"    class="form-control" placeholder="Abd**">
                    </div>
                    <div class="form-group col-md-6">
                      <label>Jumlah Pulsa</label>
                      <input name="jumlah_pulsa" type="number" class="form-control" placeholder="500***">
                    </div>
                  </div>
                  <button type="submit" class="btn btn-primary">Submit</button>
                  <a onclick="return confirm('Ingin Keluar?')"  href="homepage" class=""> Home</a>
                </form>
    </div>
  </div>
</body>
</html>