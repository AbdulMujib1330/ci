<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css">
    <title>Home</title>
</head>
<style>
    body{
        height: 50000px
    }
</style>
<body>
    <div class="card position-relative justify-intem-center">
        <div calss="card-header">
            <h1 class="text-center">This Your Data</h1>
            </div>
            <div class="card-body">
            <table class="table table-striped">
            <thead>
                <tr>
                <th scope="col">Id</th>
                <th scope="col">Nama Operator</th>
                <th scope="col">Jumlah Pulsa</th>
                <th scope="col">#</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach($data as $wt) :?>
                <tr>
                <th class="fs-5" scope="row"><?= $wt['id']?></th>
                <td class="fs-5"            ><?= $wt['nama_operator']?></td>
                <td class="fs-5"            ><?= $wt['jumlah_pulsa']?></td>
                <td class="text-center">
                    <a href=""class="btn btn-primary">Update</a>
                    <a href=""class="btn btn-danger">Delete</a>
                </td>
                </tr>
                <?php endforeach;?>
            </tbody>
            </table>
        </div>
        <a href=""class="btn btn-light w-25 mx-auto fs-4 text-center">Insert</a>
    </div>
</body>
</html>